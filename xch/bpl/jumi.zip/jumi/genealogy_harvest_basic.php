<?php

namespace BPL\Jumi\Genealogy_Harvest_Basic;

require_once 'bpl/mods/genealogy_harvest.php';

use function BPL\Mods\Genealogy_Harvest\main as genealogy;

genealogy();