<div class="col-lg-8">
    <!-- TradingView Widget BEGIN -->

    <div class="tradingview-widget-container">

        <div id="tradingview_924a4" style="height: 400px;border:3px solid #192231;">
            <div id="tradingview_5b875-wrapper"
                 style="position: relative;box-sizing: content-box;width: 100%;height: 100%;margin: 0 auto !important;padding: 0 !important;font-family:Arial,sans-serif;">
                <div style="width: 100%;height: 100%;background: transparent;padding: 0 !important;">
                    <iframe id="tradingview_5b875"
                            src="https://s.tradingview.com/widgetembed/?frameElementId=tradingview_5b875&amp;symbol=COINBASE%3AALGOUSD&amp;interval=1&amp;symboledit=1&amp;saveimage=1&amp;toolbarbg=f1f3f6&amp;studies=StochasticRSI%40tv-basicstudies&amp;theme=dark&amp;style=1&amp;timezone=Asia%2FHong_Kong&amp;studies_overrides=%7B%7D&amp;overrides=%7B%7D&amp;enabled_features=%5B%5D&amp;disabled_features=%5B%5D&amp;locale=en&amp;utm_source=trade.algoscalp.com&amp;utm_medium=widget&amp;utm_campaign=chart&amp;utm_term=COINBASE%3AALGOUSD"
                            style="width: 100%; height: 100%; margin: 0 !important; padding: 0 !important;"
                            allowtransparency="true" scrolling="no" allowfullscreen=""></iframe>
                </div>
            </div>
        </div>

        <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
        <script type="text/javascript">
            new TradingView.widget(
                {
                    "autosize": true,
                    "symbol": "COINBASE:ALGOUSD",
                    "interval": "1",
                    "timezone": "Asia/Hong_Kong",
                    "theme": "dark",
                    "style": "1",
                    "locale": "en",
                    "toolbar_bg": "#f1f3f6",
                    "enable_publishing": false,
                    "allow_symbol_change": true,
                    "studies": [
                        "StochasticRSI@tv-basicstudies"
                    ],
                    "container_id": "tradingview_924a4"

                }
            );

        </script>
    </div>
    <!-- TradingView Widget END -->
</div>