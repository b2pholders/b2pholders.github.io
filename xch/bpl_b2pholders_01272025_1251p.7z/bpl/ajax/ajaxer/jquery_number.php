<?php

namespace BPL\Ajax\Ajaxer\Jquery_Number;

/**
 *
 * @return string
 *
 * @since version
 */
function main(): string
{
	return '<script src="bpl/plugins/jquery.number.js"></script>';
}